package practica05;

public class actividad2_ExcepcionPilaLlena extends RuntimeException {
    public actividad2_ExcepcionPilaLlena(String mensaje) {
        super(mensaje);
    }
}
