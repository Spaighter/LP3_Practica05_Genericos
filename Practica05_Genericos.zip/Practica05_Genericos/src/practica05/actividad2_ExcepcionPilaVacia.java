package practica05;

public class actividad2_ExcepcionPilaVacia extends RuntimeException {
    public actividad2_ExcepcionPilaVacia(String mensaje) {
        super(mensaje);
    }
}
