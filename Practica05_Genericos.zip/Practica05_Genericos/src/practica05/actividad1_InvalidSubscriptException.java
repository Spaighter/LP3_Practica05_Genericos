package practica05;

public class actividad1_InvalidSubscriptException extends RuntimeException {
    public actividad1_InvalidSubscriptException(String mensaje) {
        super(mensaje);
    }
}
